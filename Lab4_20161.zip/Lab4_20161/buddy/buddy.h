#include <stddef.h>
void *xmalloc(size_t nbytes);
//void *xrealloc(void * ptr, size_t size);
//void xfree(void * ptr);
