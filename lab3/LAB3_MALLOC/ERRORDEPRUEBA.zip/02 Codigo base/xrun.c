#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <math.h>

void *xmalloc (size_t nbytes);
void xfree(void * ptr);

int main(void)
{ unsigned int x,unidad,base;
  /*unsigned int *pt;*/

  unidad=1024; 
  x=0;
  long* pt[8];
  long* pt1;
  do {
    base=pow(2,x)+.5;
    if((pt[x]=(long*)xmalloc(base*unidad))) 
       fprintf(stdout,"Se solicitaron %d bytes y estan ubicados en %p\n",base*unidad,pt[x]);
    else
       fprintf(stderr,"No hay suficiente memoria\n");       
    x++; }
  while(x<=7);
  xfree(pt[1]+16);
  xfree(pt[3]+16);
  xfree(pt[5]+16);
  pt1 = (long*)xmalloc(unidad);
  fprintf(stdout,"Se solicitaron %d bytes y estan ubicados en %p\n",unidad,pt1);
  exit(0);                  
  
}


