#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <math.h>

void *xmalloc (size_t nbytes);
void xfree(void * ptr);

int main(void)
{ unsigned long long int x,unidad,base;
  /*unsigned long long int *pt;*/

  unidad=1024; 
  x=0;
  unsigned long long int* pt[8];
  unsigned long long int* pt1;
  do {
    base=pow(2,x)+.5;
    if((pt[x]=(unsigned long long int*)xmalloc(base*unidad))) 
       fprintf(stdout,"Se solicitaron %lld bytes y estan ubicados en %p\n",base*unidad,pt[x]);
    else
       fprintf(stderr,"No hay suficiente memoria\n");       
    x++; }
  while(x<=3);
  pt1 = (unsigned long long int*)xmalloc(unidad);
  xfree(pt[1]);
  fprintf(stdout,"Me libere y ahora deje un hueco en %p\n",pt[1]);
  //xfree(pt[3]);
  //xfree(pt[5]);
  /*fprintf(stdout,"Se solicitaron %d bytes y estan ubicados en %p\n",unidad,pt[5]);*/
  pt1 = (unsigned long long int*)xmalloc(2*unidad);
  fprintf(stdout,"Se solicitaron %lld bytes y estan ubicados en %p\n",2*unidad,pt1);
  if(pt1 == pt[1]) printf("SI");
  else printf("NO");
  printf(" cumple First fit\n");
  //pt1 = (unsigned long long int*)xmalloc(16*240);
  //fprintf(stdout,"Se solicitaron %d bytes y estan ubicados en %p\n",unidad,pt1);
  exit(0);                  
  
}


