
/*
 * ssoo/xalloc.98/xalloc.c
 *
 * CONTENIDO INICIAL:
 *	Codigo correspondiente a la Seccion 8.7 del libro:
 *	"The C Programing Language", de B. Kernigham y D. Ritchie.
 *
 * En este fichero se incluiran las rutinas pedidas 
 *
 */

#include <unistd.h>
#include <stdio.h>
#include "xalloc.h"

/*
 * Definicion de la cabecera para huecos y bloques. 
 * La union con un campo de tipo Align fuerza que el tama~no
 * de la cabecera sea multiplo del tama~no de este tipo.
 */
typedef long Align;    /* for alignment to long boundary */

union header {   /* block header: */
	struct {
		union header *ptr;  /* next block if on free list */
		size_t size;     /* size of this block */
	} s;
	Align x;             /* force alignment of blocks */
};

typedef union header Header;

/*
 * La lista de huecos esta ordenada por direcciones y es circular.
 * base es el "falso" hueco de tama~no cero que asegura que la lista
 * nunca esta vacia 
 */
static Header base;   /* empty list to get started */

/*
 * freep apuntara al hueco situado en la lista antes del hueco
 * por el que comenzara la busqueda.
 * Necesario para implementar la estrategia next-fit
 */
static Header  *freep = NULL;  /* start of the free list */


#define NALLOC 1024

/*
 * morecore: ask system for more memory 
 *
 * Esta funcion se llama desde xmalloc cuando no hay espacio.
 * Aumenta el tama~no de la zona de datos como minimo en NALLOC*sizeof(Header)
 * y a~nade esta nueva zona a la lista de huecos usando xfree.
 *
 */

static Header *morecore(size_t nu)
{
	char *cp;
	Header *up;

	if (nu < NALLOC)	
		nu = NALLOC;
		
	printf("morecore: solicitud de %d Headers\n",(int)nu);
	
	cp= sbrk(nu * sizeof(Header));
	if (cp == (char *) -1) /* no space at all */
		return NULL;
	up = (Header *) cp;
	up ->s.size = nu;
	
	printf("morecore: header del bloque obtenido en up(%p) = %p\n",&up,up);
	printf("morecore: up->s.ptr = %p, ",up->s.ptr);
	printf("up->s.size = %d\n",(int)up->s.size);
	printf("morecore: insertarlo en free list\n\n");
	
	xfree((void *)(up+1));
	
	printf("morecore: devolviendo freep(%p) = %p\n\n",&freep,freep);
	
	return freep;
}

/* xmalloc: general-purpose storage allocator */
void *xmalloc (size_t nbytes)
{
	Header  *p, *prevp;
	size_t nunits;

	/* 
	   Calcula cuanto ocupara la peticion medido en tama~nos de
	   cabecera (incluyendo la propia cabecera). 
	   El termino "sizeof(Header)-1" provoca un redondeo por exceso.
	   El termino "+ 1" es para incluir la propia cabecera.
	*/
	nunits = (nbytes+sizeof(Header)-1)/sizeof(Header) + 1;
	
	printf("xmalloc: solicitud de %d Headers\n",(int)nunits);


	/* En la primera llamada se construye una lista de huecos con un
	   unico elemento de tama~no cero (base) que se apunta a si mismo */
	if (( prevp = freep) == NULL ) { /* no free list yet */
		base.s.ptr = freep = prevp = & base; 
		base.s.size = 0;
	}

	printf("xmalloc: freep(%p) = %p\n",&freep,freep);
	
	/*
	   Recorre la lista circular de huecos, empezando por el siguiente al
	   que apunta freep, hasta que encuentra uno que satisface la peticion
	   o da toda una vuelta a la lista (no hay espacio suficiente)
	*/

	int i = 0;
	for (p= prevp->s.ptr; ; prevp = p, p = p->s.ptr) {
		i++;
		printf("-------------BUCLE %d:\n", i); 
		printf("xmalloc: prevp(%p) = %p tiene:\n", &prevp, prevp);
		printf("xmalloc: prevp->s.ptr = %p, ", prevp->s.ptr);
		printf("prevp->s.size = %d\n", (int)prevp->s.size);
		printf("xmalloc: p(%p) = %p tiene:\n", &p, p);
		printf("xmalloc: p->s.ptr = %p, ", p->s.ptr);
		printf("p->s.size = %d\n\n", (int)p->s.size);
		
		if (p->s.size >= nunits) {  /* big enough */
			//Johana: Cuando la cantidad pedida es la cantidad requerida el siguiente del puntero prevp
			//es el siguiente del puntero P por que el p será ocupado por el dato 
			if (p->s.size == nunits)  /* exactly */
				prevp->s.ptr = p->s.ptr;
			//Johana: en caso sobre espacio se reduce el size del hueco
			else {  /* allocate tail end */
				p->s.size -= nunits;
				
				printf("xmalloc: p(%p) = %p adjusting:\n", &p, p);
				printf("xmalloc: p->s.ptr = %p, ", p->s.ptr);
				printf("p->s.size = %d\n\n", (int)p->s.size);

				p+= p->s.size;
				p->s.size = nunits;
				
				printf("xmalloc: p(%p) = %p adjusting:\n", &p, p);
				printf("xmalloc: p->s.ptr = %p, ", p->s.ptr);
				printf("p->s.size = %d\n\n", (int)p->s.size);
				
			}
			/* Glenn: Si quiero first-fit
			freep = base;
			*/
			freep = prevp; /* estrategia next-fit */
			
			printf("xmalloc: freep(%p) = %p tiene:\n", &freep,freep);
			printf("xmalloc: freep->s.ptr = %p, ", freep->s.ptr);
			printf("freep->s.size = %d\n\n", (int)freep->s.size);

			return (void *)(p+1); /* devuelve un puntero a la
						 zona de datos del bloque */
		}
		/* Si ha dado toda la vuelta pide mas memoria y vuelve
		   a empezar */
		if (p == freep) /* wrapped around free list */
		
			printf("xmalloc: needs more storage from the OS\n\n");
			
			if ((p = morecore(nunits)) == NULL)
				return NULL;  /* none left */
				
			printf("xmalloc: seguir buscando. Ahora\n");
			printf("xmalloc: p(%p) = %p tiene:\n", &p, p);
			printf("xmalloc: p->s.ptr = %p, ", p->s.ptr);
			printf("p->s.size = %d\n\n", (int)p->s.size);
			
	}
}


/* xfree: put block ap in the free list */
void xfree(void *ap)
{
	Header *bp, *p;

	bp = (Header *)ap - 1;  /* point to block header */

	printf("xfree: header del bloque al insertar en bp(%p) = %p\n",&bp,bp);

	/*
	   Bucle que recorre la lista de huecos para buscar el hueco
	   anterior al bloque que se va a liberar.
	   Del bucle se sale cuando se encuentran los dos huecos
	   de la lista (el apuntado por p y el apuntado por p->s.ptr)
	   entre los que se incluira el nuevo hueco (el apuntado por bp).
	   Hay dos casos:
		- La direccion del nuevo hueco es mayor (bp > p) o
		menor (bp < p->s.ptr) que la de ningun otro hueco de la
		lista (corresponde al break)
		- La direccion del nuevo hueco esta comprendida entre
		dos huecos de la lista (corresponde a la salida normal
		del for)
	*/

	printf("xfree: bp->s.ptr = %p, ",bp->s.ptr);
	printf("bp->s.size = %d\n\n",(int)bp->s.size);

	for (p= freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
		if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
			/* Glenn: Si el nuevo hueco ahora es la menor direccion de memoria entonces
			if (p >= p->s.ptr && bp < p->s.ptr)
				base = bp
			*/
			break;  /* freed block at start or end of arena */ 


	/* Comprueba compactacion con hueco posterior */
	if (bp + bp->s.size == p->s.ptr) {  /* join to upper nbr */
		bp->s.size += p->s.ptr->s.size;
		bp->s.ptr = p->s.ptr->s.ptr;
	} else
		 bp->s.ptr = p->s.ptr;
		 
	printf("xfree: bp->s.ptr = %p, ",bp->s.ptr);
	printf("bp->s.size = %d\n\n",(int)bp->s.size);

	/* Comprueba compactacion con hueco anterior */
	if (p + p->s.size == bp) {         /* join to lower nbr */
		p->s.size += bp->s.size;
		p->s.ptr = bp->s.ptr;
	} else
		p->s.ptr = bp;
		
	printf("xfree: p->s.ptr = %p, ",p->s.ptr);
	printf("p->s.size = %d\n\n",(int)p->s.size);

	/* Glenn: Si quiero first-fit
	freep = base;
	*/
	freep = p; /* estrategia next-fit */
	
	printf("xfree: base(%p): base.s.ptr = %p, base.s.size = %d\n",
	&base,base.s.ptr,(int)base.s.size);
	printf("xfree: freep(%p) = %p\n\n",&freep,freep);
	
}

void *xrealloc(void * ptr, size_t size)
{
	return NULL;
}
