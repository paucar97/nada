#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <math.h>

void *xmalloc (size_t nbytes);

int main(void)
{ unsigned int x,unidad,base;
  unsigned int *pt;

  unidad=1024; 
  x=0;
  int i=0;
  do {
    i++;
    base=pow(2,x)+.5;
    printf("\n----------SOLICITUD DE MEMORIA %d:\n", i);
    if((pt=(unsigned int *)xmalloc(base*unidad))) 
       fprintf(stdout,"Se solicitaron %d bytes y estan ubicados en %p\n",base*unidad,pt);
    else
       fprintf(stderr,"No hay suficiente memoria\n");       
    x++; }
  while(x<=1);      
  exit(0);                  
  
}


