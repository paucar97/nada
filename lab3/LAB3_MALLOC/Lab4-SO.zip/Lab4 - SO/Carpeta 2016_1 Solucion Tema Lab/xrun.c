/*
 *
 * CONTENIDO INICIAL:
 *	Esqueleto del programa xrun
 *
 * Debera completarse con la funcionalidad pedida en el enunciado
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "xalloc.h"

/* 
 *  Tama'no maximo de cada linea (tanto la del nombre de comando
 *  como la de cada argumento)
 */
#define MAX_ARG_LONG 255

#define ESCAPE '\033'

/*
 * Funcion err_exit: imprime un mensaje de error y termina el programa
 */

void err_exit(char * mensaje)
{
	fprintf(stderr, "%s\n", mensaje);
	exit(1);
}

void main(void)
{
	int num_args=0;
	char *linea;
        char **comandos = NULL; 
        int i,j;

	setbuf(stdout, NULL); /* Elimina el buffering de la salida est�ndar */

	num_args=0; /* numero de argumentos incluido el nombre del comando */


	/* Reserva espacio para leer una linea */
	if ((linea=(char*)xmalloc(MAX_ARG_LONG))==NULL)
		err_exit("Error reservando espacio con xmalloc");

        comandos = (char**)xmalloc(sizeof(char*));

	/* Bucle que lee lineas hasta que detecta el final del fichero */
	while (fgets(linea, MAX_ARG_LONG, stdin)!=NULL)
	{
		/* elimina el caracter salto de linea del string */
		linea[strlen(linea)-1]='\0';
                 
		/* Comprueba si hay un ESCAPE al principio de la linea */
		if (linea[0]=='X')
		{
			/* Comando anulado. Se debe liberar toda la memoria
			   dinamica reservada. En la siguiente linea
			   comenzara  el nuevo comando */ 
                        for (i=0; i<num_args; i++) {
                            xfree(comandos[i]);  
                        }
                        if (comandos != NULL) 
                           xfree(comandos);

			comandos = (char**)xmalloc(sizeof(char*));
			num_args=0;
			printf("Comando anulado\n");
		}
		else
		{
			/* Nuevo argumento. Se debe redimensionar  el
			   vector de punteros y referenciar desde la
			   posicion correspondiente de dicho vector
			   al nuevo argumento. Asimismo, se debe
			   reservar espacio para leer la proxima linea*/
                         
                           comandos[num_args] = linea;
		 	   comandos = (char**)xrealloc(comandos,
                                		sizeof(char*)*(num_args+2));
                           
			   printf("argumento[%d]: %s\n", num_args, linea);
			   num_args++;
		}
		
		if ((linea=(char*)xmalloc(MAX_ARG_LONG))==NULL)
			err_exit("Error reservando espacio con xmalloc");
	}
	/* Entrada de datos terminada. Antes de ejecutar el comando
	   debe ponerse un valor nulo en el ultimo componente del vector
	   de punteros */

	comandos[num_args] = NULL;
	
	if (num_args>0)
	{
		/* Ejecutar el comando con execvp (man execvp) */           
                execvp(comandos[0], comandos);
	}
	else
		err_exit("No ha intoducido ningun comando");
}

