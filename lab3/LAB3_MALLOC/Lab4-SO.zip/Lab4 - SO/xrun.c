#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "xalloc.h"

typedef long Align;    /* for alignment to long boundary */

union header {   /* block header: */
	struct {
		union header *ptr;  /* next block if on free list */
		size_t size;     /* size of this block */
	} s;
	Align x;             /* force alignment of blocks */
};

typedef union header Header;


void main(void) {
	int i;
	int *p;

	p = (int*)xmalloc(2*sizeof(int));
	printf("Reservo con xmalloc : %d headers\n", 2*sizeof(int) / sizeof(Header)); 
 
	p[0] = 1;
	p[1] = 1; 
 
	printf(" : antes %d %d \n",p[0],p[1]); 

	p = (int*)xrealloc(p,16*sizeof(int));
	printf("Reservo con xrealloc : %d headers\n", 16*sizeof(int) / sizeof(Header)); 

	for(i=0;i<16;i++) {
    	if (i>1) p[i]=i;
		printf(" : despues  %d \n",p[i]); 
	}
	p=(int*)xrealloc(p,2*sizeof(int));
	printf("Reservo con xrealloc : %d headers\n", 2*sizeof(int) / sizeof(Header)); 
	printf(" : antes %d %d \n",p[0],p[1]); 

	p=(int*)xrealloc(p,4*sizeof(int));
	printf("Reservo con xrealloc : %d headers\n", 4*sizeof(int) / sizeof(Header));   
	for(i=0;i<4;i++) {
    	if (i>1) p[i]=i;
		printf("%d \n",p[i]); 
	} 
 
	if (p!=NULL) {   
		free(p);
  	}
}
